# حزمة النشر الكاملة — قمهد لايف (واجهة Next ثابتة + خلفية PHP)

هذه الحزمة **جاهزة للرفع مباشرة** ولا ينقصها شيء. تحتوي على:

- **خلفية PHP كاملة كما هي** (بما فيها إصلاح خريطة الفيديو): `app/`,
  `public/api/*.php`, `public/index.php`, `btolat_php_api/`, `storage/`,
  `config`, والبث المباشر و`stream` و`yacine` والـ Proxy والتواقيع.
- **واجهة Next.js الثابتة مبنية ومدمجة داخل `public/`**: `index.html`,
  `_next/`, `news/`, `videos/`, `standings/` … إلخ.

## طريقة الرفع

1. افتح مدير الملفات في الاستضافة (cPanel/DirectAdmin) وادخل `public_html`.
2. احذف/انسخ احتياطياً محتوى الموقع القديم إن رغبت.
3. ارفع **محتويات هذا المجلد** (`www.qamhad.com/`) إلى `public_html` كما هي
   بنفس الترتيب: `app/`, `public/`, `storage/`, `btolat_php_api/`, `.htaccess`
   الجذري … إلخ.
4. تأكّد أن مجلد `storage/` قابل للكتابة (عادةً 755 أو 775).
5. افتح `https://qamhad.com` — يعمل مباشرة. **بدون npm ولا node ولا pm2.**

> ملف `.htaccess` الجذري يوجّه كل شيء داخلياً إلى `public/` (كما كان)، وملف
> `public/.htaccess` يخدم صفحات Next الثابتة مباشرة، ويمرّر كل ما هو ديناميكي
> إلى `index.php` (خلفية PHP دون تعديل).

## من يخدم ماذا؟

| المسار | يُخدَم بواسطة |
|---|---|
| `/` ، `/matches` ، `/news` ، `/videos` ، `/standings` ، `/leagues` ، الصفحات الثابتة | **Next ثابت** (HTML سريع) |
| `/match/{slug}` (مركز المباراة + البث الحي + SEO) | **PHP** |
| `/news/{slug}` ، `/video/{id}` ، `/team/{slug}` ، `/player/{slug}` ، `/league/{slug}` | **PHP** (SEO كامل لكل عنصر) |
| `/api/*` ، `/stream` ، `/media/*` ، `/watch/*` ، `/yacine/*` | **PHP** (بيانات حية + بث) |
| `/search` ، `/sitemap*.xml` | **PHP** |

بهذا التقسيم: صفحات التصفّح أصبحت ثابتة وسريعة (Next)، وكل ما يحتاج خادماً
(بث/بيانات لحظية/أسرار/SEO ديناميكي) بقي في PHP كما هو تماماً — وبذلك لا يتعطّل
البث المباشر ولا تفقد أي روابط SEO.

## تحديث الواجهة لاحقاً

الشيفرة المصدرية لواجهة Next في `qamhad-next-project.zip`. لتعديل الواجهة:

```bash
cd qamhad-next
npm install
npm run build          # يُنتج out/
```

ثم انسخ محتويات `out/` فوق مجلد `public/` (مع إبقاء `index.php` و`api/` وبقية
ملفات PHP)، دون استبدال `public/.htaccess` بالنسخة المبسّطة — احتفظ بنسخة
`public/.htaccess` الموجودة في هذه الحزمة.
